const SUCCESS = "success";
const FAIL = "fail";
const ERROR = "error";

module.exports = {
    SUCCESS,
    FAIL,
    ERROR
}